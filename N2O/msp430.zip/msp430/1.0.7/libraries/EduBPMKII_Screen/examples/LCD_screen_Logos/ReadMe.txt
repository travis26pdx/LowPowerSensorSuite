
  LCD_screen_Logos
  Project
  ----------------------------------
  Developed with embedXcode

  Project LCD_screen_Logos
  Created by Rei VILO on 26/07/13
  Copyright © 2013 Rei Vilo
  Licence All rights reserved



  References
  ----------------------------------



  embedXcode
  embedXcode+
  ----------------------------------
  Embedded Computing Template on Xcode 4
  Copyright © Rei VILO, 2010-2013
  All rights reserved
  embedXcode • Jul 20, 2013 release 101 • Stability enhancements
  http://embedXcode.weebly.com/

