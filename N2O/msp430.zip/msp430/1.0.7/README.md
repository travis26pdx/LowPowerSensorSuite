# msp430-lg-core
