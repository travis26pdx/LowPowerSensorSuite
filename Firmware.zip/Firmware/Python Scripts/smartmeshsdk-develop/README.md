SmartMeshSDK
============

Python SmartMesh SDK

* [Documentation](https://dustcloud.atlassian.net/wiki/display/SMSDK)
* [Discussion](https://dustcloud.atlassian.net/wiki/questions)
* [Issue tracking](https://dustcloud.atlassian.net/browse/SMSDK)

For Windows executable versions of the applications, see [Releases](https://github.com/dustcloud/smartmeshsdk/releases)
