#ifndef DN_CLIB_VERSION_H
#define DN_CLIB_VERSION_H

#include "dn_clib_build.h"

enum {
   VER_MAJOR = 1,
   VER_MINOR = 0,
   VER_PATCH = 2,
};

#endif